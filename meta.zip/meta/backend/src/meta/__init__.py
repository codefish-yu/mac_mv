__version__ = '0.0.1'

default_app_config = 'meta.apps.MetaConfig'