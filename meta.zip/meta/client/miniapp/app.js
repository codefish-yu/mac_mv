//app.js
App({
  onLaunch: function () {
    this.domain = 'https://whitedinner.metatype.cn';
  },

  pages: []
})